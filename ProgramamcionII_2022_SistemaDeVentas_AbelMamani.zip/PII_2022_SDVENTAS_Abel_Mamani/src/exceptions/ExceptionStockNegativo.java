package exceptions;

public class ExceptionStockNegativo extends ExceptionStock{
	public ExceptionStockNegativo(String msg) {
		super(msg);
	}
}
