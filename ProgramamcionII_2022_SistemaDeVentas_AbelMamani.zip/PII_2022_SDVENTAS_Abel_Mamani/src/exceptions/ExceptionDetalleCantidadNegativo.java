package exceptions;

public class ExceptionDetalleCantidadNegativo extends ExceptionDetalle{
	public ExceptionDetalleCantidadNegativo(String msg) {
		super(msg);
	}
}
