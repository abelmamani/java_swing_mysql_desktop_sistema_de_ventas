package exceptions;

public class ExceptionVentaClienteNulo extends ExceptionVenta{
	public ExceptionVentaClienteNulo(String msg) {
		super(msg);
	}
}
