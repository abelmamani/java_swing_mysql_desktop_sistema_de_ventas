package exceptions;

public class ExceptionDetallePrecioCero extends ExceptionDetalle{
	public ExceptionDetallePrecioCero(String msg) {
		super(msg);
	}
}
