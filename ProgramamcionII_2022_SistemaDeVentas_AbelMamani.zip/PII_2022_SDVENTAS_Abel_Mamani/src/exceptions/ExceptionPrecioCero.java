package exceptions;

public class ExceptionPrecioCero extends ExceptionPrecio{
	public ExceptionPrecioCero(String msg) {
		super(msg);
	}
}
