package exceptions;

public class ExceptionVenta extends Exception{
	public ExceptionVenta(String msg) {
		super(msg);
	}
}
