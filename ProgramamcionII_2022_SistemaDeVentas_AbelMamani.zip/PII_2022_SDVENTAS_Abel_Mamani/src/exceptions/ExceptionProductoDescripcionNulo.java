package exceptions;

public class ExceptionProductoDescripcionNulo extends ExceptionProducto{
	public ExceptionProductoDescripcionNulo(String msg) {
		super(msg);
	}
}
