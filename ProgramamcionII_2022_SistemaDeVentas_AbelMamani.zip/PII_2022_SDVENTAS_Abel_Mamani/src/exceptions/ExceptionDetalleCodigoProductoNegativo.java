package exceptions;

public class ExceptionDetalleCodigoProductoNegativo extends ExceptionDetalle{
	public ExceptionDetalleCodigoProductoNegativo(String msg) {
		super(msg);
	}
}
