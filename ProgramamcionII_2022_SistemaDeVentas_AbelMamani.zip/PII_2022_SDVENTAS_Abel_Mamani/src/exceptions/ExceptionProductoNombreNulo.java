package exceptions;

public class ExceptionProductoNombreNulo extends ExceptionProducto{
	public ExceptionProductoNombreNulo(String msg) {
		super(msg);
	}
}
