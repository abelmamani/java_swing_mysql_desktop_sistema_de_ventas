package exceptions;

public class ExceptionProductoTipoDeProductoNulo extends ExceptionProducto{
	public ExceptionProductoTipoDeProductoNulo(String msg) {
		super(msg);
	}
}
