package exceptions;

public class ExceptionDetalle extends Exception{
	public ExceptionDetalle(String msg) {
		super(msg);
	}
}
