package exceptions;

public class ExceptionStock extends Exception{
	public ExceptionStock(String msg) {
		super(msg);
	}
}
