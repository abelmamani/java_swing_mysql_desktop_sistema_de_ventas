package exceptions;

public class ExceptionVentaClienteNumero extends ExceptionVenta{
	public ExceptionVentaClienteNumero(String msg) {
		super(msg);
	}
}
