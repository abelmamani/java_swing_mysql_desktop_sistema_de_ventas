package exceptions;

public class ExceptionPrecio extends Exception{
	public ExceptionPrecio(String msg) {
		super(msg);
	}
}
