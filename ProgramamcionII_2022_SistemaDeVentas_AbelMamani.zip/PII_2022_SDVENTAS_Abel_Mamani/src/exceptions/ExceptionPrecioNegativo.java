package exceptions;

public class ExceptionPrecioNegativo extends ExceptionPrecio{
	public ExceptionPrecioNegativo(String msg) {
		super(msg);
	}
}
