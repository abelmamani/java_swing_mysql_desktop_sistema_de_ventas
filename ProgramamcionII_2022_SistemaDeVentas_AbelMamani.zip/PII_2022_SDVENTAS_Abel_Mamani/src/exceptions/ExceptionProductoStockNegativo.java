package exceptions;

public class ExceptionProductoStockNegativo extends ExceptionProducto{
	public ExceptionProductoStockNegativo(String msg) {
		super(msg);
	}
}
