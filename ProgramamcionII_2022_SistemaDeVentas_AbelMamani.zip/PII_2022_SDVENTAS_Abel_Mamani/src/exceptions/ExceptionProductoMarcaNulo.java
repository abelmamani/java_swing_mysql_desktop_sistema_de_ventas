package exceptions;

public class ExceptionProductoMarcaNulo extends ExceptionProducto{
	public ExceptionProductoMarcaNulo(String msg) {
		super(msg);
	}
}
