package exceptions;

public class ExceptionVentaClienteVacio extends ExceptionVenta{
	public ExceptionVentaClienteVacio(String msg) {
		super(msg);
	}
}
