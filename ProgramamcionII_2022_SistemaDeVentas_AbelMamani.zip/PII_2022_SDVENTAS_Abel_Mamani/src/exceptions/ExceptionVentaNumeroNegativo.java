package exceptions;

public class ExceptionVentaNumeroNegativo extends ExceptionVenta{
	public ExceptionVentaNumeroNegativo(String msg) {
		super(msg);
	}
}
