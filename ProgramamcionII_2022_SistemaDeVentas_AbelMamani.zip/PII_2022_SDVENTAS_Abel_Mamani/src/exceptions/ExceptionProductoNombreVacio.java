package exceptions;

public class ExceptionProductoNombreVacio extends ExceptionProducto{
	public ExceptionProductoNombreVacio(String msg) {
		super(msg);
	}
}
