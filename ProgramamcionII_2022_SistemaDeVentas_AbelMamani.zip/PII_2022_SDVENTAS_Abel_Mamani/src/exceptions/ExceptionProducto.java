package exceptions;

public class ExceptionProducto extends Exception{
	public ExceptionProducto(String msg) {
		super(msg);
	}
}
