package exceptions;

public class ExceptionVentaMedioDePagoNulo extends ExceptionVenta{
	public ExceptionVentaMedioDePagoNulo(String msg) {
		super(msg);
	}
}
