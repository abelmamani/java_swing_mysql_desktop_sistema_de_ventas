package exceptions;

public class ExceptionDetallePrecioNegativo extends ExceptionDetalle{
	public ExceptionDetallePrecioNegativo(String msg) {
		super(msg);
	}
}
