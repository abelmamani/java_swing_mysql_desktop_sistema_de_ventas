package exceptions;

public class ExceptionVentaFechaNulo extends ExceptionVenta{
	public ExceptionVentaFechaNulo(String msg) {
		super(msg);
	}
}
