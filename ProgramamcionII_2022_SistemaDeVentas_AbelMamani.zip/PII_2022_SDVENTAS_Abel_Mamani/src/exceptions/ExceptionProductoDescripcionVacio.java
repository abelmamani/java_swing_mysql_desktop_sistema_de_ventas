package exceptions;

public class ExceptionProductoDescripcionVacio extends ExceptionProducto{
	public ExceptionProductoDescripcionVacio(String msg) {
		super(msg);
	}
}
