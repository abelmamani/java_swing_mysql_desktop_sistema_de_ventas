package exceptions;

public class ExceptionProductoCodigoProductoNegativo extends ExceptionProducto{
	public ExceptionProductoCodigoProductoNegativo(String msg) {
		super(msg);
	}
}
