package dominio;

public enum MedioDePago {
	EFECTIVO, CREDITO, DEBITO, CHEQUE, PAYPAL, MERCADOPAGO;
}
